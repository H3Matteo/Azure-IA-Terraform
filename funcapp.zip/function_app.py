import azure.functions as func
import logging
import os
import requests
from azure.storage.blob import BlobServiceClient

app = func.FunctionApp()

@app.blob_trigger(
    arg_name="inputblob",
    path="images/{name}",
    connection="AzureWebJobsStorage"
)
def ocr_function(inputblob: func.InputStream):

    logging.info(f"Processing blob: {inputblob.name}")

    # Récupération des variables d’environnement
    vision_endpoint = os.environ["VISION_ENDPOINT"]
    vision_key = os.environ["VISION_KEY"]
    storage_url = os.environ["STORAGE_ACCOUNT_URL"]

    headers = {
        "Ocp-Apim-Subscription-Key": vision_key,
        "Content-Type": "application/octet-stream"
    }

    response = requests.post(
        f"{vision_endpoint}/vision/v3.2/ocr",
        headers=headers,
        data=inputblob.read()
    )

    result = response.json()

    extracted_text = ""
    for region in result.get("regions", []):
        for line in region.get("lines", []):
            for word in line.get("words", []):
                extracted_text += word["text"] + " "

    blob_service_client = BlobServiceClient(account_url=storage_url, credential=os.environ["STORAGE_KEY"])

    blob_client = blob_service_client.get_blob_client(
        container="results",
        blob=f"{inputblob.name}.txt"
    )

    blob_client.upload_blob(extracted_text, overwrite=True)

    logging.info("OCR processing completed.")